package ru.calc.model;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import ru.calc.model.Elements.*;

public class Calc {
  public Integer userId;
  public String name;
  public String type;
  public List<Element> elements;
  //public Result result;

  public Calc() {}
  public Calc(String name) {this.name = name;}

  public void init() {}

  public String getResult(Result res) {return null;}

  public Result getDefaultResult() {return null;}

  public void setElements(List<Element> elements) {

  }
}
