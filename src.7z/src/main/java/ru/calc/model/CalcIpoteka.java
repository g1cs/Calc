package ru.calc.model;

import ru.calc.model.Elements.*;
import ru.calc.model.Elements.Enum;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

public class CalcIpoteka extends Calc {

  public CalcIpoteka(String name) {
    super(name);
  }

  public void init() {
    type = "Ипотека";

    elements = new ArrayList<>();
    elements.add(new Element(Enum.Names.sumRealty.getId(), Enum.Names.sumRealty.getName(),
        "slider", new ElementInfoSlider(Enum.Names.sumRealty.getInfo(), Enum.Names.sumRealty.getDefaultValue(),
        0.0, 50000000.0)));
    elements.add(new Element(Enum.Names.sumRealty.getId(), Enum.Names.sumRealty.getName(),
        "slider", new ElementInfoSlider(Enum.Names.sumRealty.getInfo(), Enum.Names.sumRealty.getDefaultValue(),
        0.0, 50000000.0)));
  }

  public Result getDefaultResult() {

    List<ListValue> el = new ArrayList<>();
    return new Result(null, null, el);
  }

  public static String getResult(Result defaultRes, List<Element> res) {

    return null;
  }
}

