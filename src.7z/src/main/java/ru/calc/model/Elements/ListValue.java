package ru.calc.model.Elements;

public class ListValue
{
  public String name;
  public Double value;

  public ListValue(String name, Double value){
    this.name = name;
    this.value = value;
  }
}