package ru.calc.model.Elements;

class ListElemsCalc
{
  String name;
  Double value;

  public ListElemsCalc(String name, Double value){
    this.name = name;
    this.value = value;
  }
}
