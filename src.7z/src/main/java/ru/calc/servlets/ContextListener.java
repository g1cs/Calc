package ru.calc.servlets;

import ru.calc.dao.UserDAO;
import ru.calc.model.Calc;
import ru.calc.model.CalcCredit;
import ru.calc.model.CalcOsago;
import ru.calc.model.User;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicReference;

import static ru.calc.model.User.ROLE.ADMIN;
import static ru.calc.model.User.ROLE.USER;

@WebListener
public class ContextListener implements ServletContextListener {
  /**
   * Fake database connector.
   */
  private AtomicReference<UserDAO> users;
  private List<Calc> defaultCalcs;
  private List<Calc> calcs;

  @Override
  public void contextInitialized(ServletContextEvent servletContextEvent) {

    users = new AtomicReference<>(new UserDAO());

    User user1 = new User(1, "admin", "admin", ADMIN);
    users.get().add(user1);
    users.get().add(new User(2, "user", "user", USER));

    defaultCalcs = new CopyOnWriteArrayList<>();
    calcs = new CopyOnWriteArrayList<>();

    final CalcOsago calcOsago = new CalcOsago("Калькулятор Осаго");
    calcOsago.init();
    calcOsago.userId = user1.getId();
    this.defaultCalcs.add(calcOsago);
    final CalcCredit calcCredit = new CalcCredit("Кредитный калькулятор");
    calcCredit.init();
    calcCredit.userId = user1.getId();
    this.defaultCalcs.add(calcCredit);

    final ServletContext servletContext =
        servletContextEvent.getServletContext();

    servletContext.setAttribute("users", users);
    servletContext.setAttribute("defaultCalcs", defaultCalcs);
    servletContext.setAttribute("calcs", calcs);
  }

  @Override
  public void contextDestroyed(ServletContextEvent sce) {
    users = null;
  }
}