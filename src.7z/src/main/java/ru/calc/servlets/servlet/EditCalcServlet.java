package ru.calc.servlets.servlet;

import ru.calc.model.*;
import ru.calc.model.Elements.*;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;


@WebServlet("/editAjax")
public class EditCalcServlet extends HttpServlet {

//  public static Calc calc;

  private static List<Calc> defaultCalcs;
  private static List<Calc> calcs;

  @Override
  public void init() throws ServletException {

    final Object defaultCalcs = getServletContext().getAttribute("defaultCalcs");
    final Object calcs = getServletContext().getAttribute("calcs");

    if (defaultCalcs == null || !(defaultCalcs instanceof CopyOnWriteArrayList) ||
        calcs == null || !(calcs instanceof CopyOnWriteArrayList)) {

      throw new IllegalStateException("You're repo does not initialize!");
    } else {

      EditCalcServlet.defaultCalcs = (CopyOnWriteArrayList<Calc>) defaultCalcs;
      EditCalcServlet.calcs = (CopyOnWriteArrayList<Calc>) calcs;
    }
  }

  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {

    System.out.println("PageIndexServlet_GET");
    final HttpSession session = request.getSession();
    final User.ROLE role = (User.ROLE) session.getAttribute("role");
    System.out.println(role);

    if (!role.equals(User.ROLE.UNKNOWN)) {

      List<String> list = new ArrayList<>();
      list.add("Осаго");
      list.add("Кредит");
      list.add("Вклады");
      list.add("Ипотека");
      list.add("Тариф сотовой связи");

      response.setContentType("application/json");
      response.setCharacterEncoding("UTF-8");
      response.getWriter().write(new Gson().toJson(list));
    }
  }

  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {

    System.out.println("PageIndexServlet_POST");
    final HttpSession session = request.getSession();
    final User.ROLE role = (User.ROLE) session.getAttribute("role");
    final Integer userId = (Integer) session.getAttribute("userId");
    System.out.println(role);
    System.out.println(userId);

    if (!role.equals(User.ROLE.UNKNOWN)) {
      JsonObject data = new Gson().fromJson(request.getReader(), JsonObject.class);
      String json = getJsonResult(data, userId);

      response.setContentType("application/json");
      response.setCharacterEncoding("UTF-8");
      response.getWriter().write(json);
    }
  }
  
  private String getJsonResult(JsonObject data, Integer userId) {

    String typeCalc = data.get("typeCalc").getAsString();
    String query = data.get("query").getAsString();
    
    switch (query) {
      case "GET":
        return getJsonResultOnQueryGet(userId, typeCalc);

      case "SAVE":
        JsonElement jsonElement = data.get("list");
        return getJsonResultOnQuerySave(userId, typeCalc, data.get("name").getAsString(), jsonElement);

      case "RES":
        JsonElement jsonElementList = data.get("list");
        return getJsonResultOnQueryRes(userId, typeCalc, data.get("name").getAsString(), jsonElementList);

      default:
        return "Ошибка!";
    }
  }


  private String getJsonResultOnQueryGet(Integer userId, String typeCalc) {
    Gson gson = new Gson();
    switch (typeCalc) {
      case "Осаго":
      case "Кредит":
        for (Calc calc : defaultCalcs)
          if (calc.userId.equals(userId) && calc.type.equals(typeCalc))
            return gson.toJson(calc);
      case "ALL":
        List<Calc> resList = new CopyOnWriteArrayList<>();
        for (Calc calc : defaultCalcs) {
          if (calc.userId.equals(userId))
            resList.add(calc);
        }
        return gson.toJson(resList);
      case "Вклады":
      case "Ипотека":
      default:
        return "Ошибка!";
    }
  }


  private CalcOsago toCalcOsagoFromJsonElement(Integer userId, String name, JsonElement jsonElement) {

    CalcOsago calc = new CalcOsago(name);
    Type listType = new TypeToken<List<ListValue>>() {}.getType();
    List<ListValue> list = new Gson().fromJson(jsonElement, listType);

    return null;
  }

  private String getJsonResultOnQuerySave(Integer userId, String typeCalc, String name, JsonElement jsonElement) {

//    Type listType = new TypeToken<List<Element>>() {}.getType();
//    List<Element> elements = new Gson().fromJson(jsonElement, listType);

    if (getJsonResultOnQueryRes(userId, typeCalc, name, jsonElement).equals("Ошибка!"))
      return "Ошибка! Не правильно составлен калькулятор.";

    Calc newCalc = null;
    switch (typeCalc) {
      case "Осаго": {
        newCalc = new CalcOsago(name);
        Type listType = new TypeToken<List<Element>>() {}.getType();
        List<Element> list = new Gson().fromJson(jsonElement, listType);
        ((CalcOsago) newCalc).setElements(list);
      } break;
      case "Кредит": {
        newCalc = new CalcCredit(name);
        Type listType = new TypeToken<List<Element>>() {}.getType();
        List<Element> list = new Gson().fromJson(jsonElement, listType);
        ((CalcCredit) newCalc).setElements(list);
      } break;
      case "Вклады": {
      } break;
      case "Ипотека": {
      } break;
      default: break;
    }
    newCalc.userId = userId;
    newCalc.type = typeCalc;
    EditCalcServlet.calcs.add(newCalc);
    return new Gson().toJson(newCalc);
  }

  private String getJsonResultOnQueryRes(Integer userId, String typeCalc, String name, JsonElement jsonElement) {

    String json = "", out = "";
    
    switch (typeCalc) {
      case "Осаго": {
        CalcOsago calc = new CalcOsago(name);
        Type listType = new TypeToken<List<ListValue>>() {}.getType();
        List<ListValue> list = new Gson().fromJson(jsonElement, listType);
        out = calc.getResult(calc.getDefaultResult(), list);
        System.out.println(out);
        json = new Gson().toJson(out);
      }
      break;
      case "Кредит": {
        CalcCredit calc = new CalcCredit(name);
        Type listType = new TypeToken<List<Element>>() {}.getType();
        List<Element> list = new Gson().fromJson(jsonElement, listType);
        json = calc.getResult(calc.getDefaultResult(), list);
        System.out.println(json);
//            json = new Gson().toJson(out);
      }
      break;
      case "Вклады": {
      }
      break;
      case "Ипотека": {
      }
      break;
      default:
        break;
    }
    
    return json;
  }
  
}